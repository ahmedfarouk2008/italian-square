package com.italian_square.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
